(function ($, w, d, h, b) {

    var app = {

        custom_script: function () {
            
        },

    }


    jQuery(document).ready(function () {
        app.custom_script();;

    });

    jQuery(window).on('load', function () {

        
    })


})(jQuery, window, document, 'html', 'body');
